<?php 

function getCookiesContent() {
    return
    '<div class="cookie-popup">
    <button id="cookie-close">OK.</button>  
    <p>Táto webstránka používa súbory cookies na prispôsobenie obsahu. 
        Jedná sa o tretie strany, ktoré príslušné informácie môžu skombinovať spolu s ďalšími údajmi, ktoré ste im poskytli alebo ktoré od vás získali, keď ste používali ich služby. Používaním tejto stránky súhlasíte s ich ukladaním.</p>
        
    </div>';
} 